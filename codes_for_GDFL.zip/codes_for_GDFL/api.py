import requests
import json
import os
from config import BASE_URL, HEADERS

class DeltaAPIClient:
    @staticmethod
    def make_request(endpoint, params=None):
        """Make a GET request to the Delta Exchange API"""
        url = f"{BASE_URL}/{endpoint}"
        try:
            response = requests.get(url, headers=HEADERS, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"API request failed: {e}")
            return None

    @staticmethod
    def save_to_file(data, filename, output_dir):
        """Save data to a JSON file"""
        os.makedirs(output_dir, exist_ok=True)
        filepath = os.path.join(output_dir, filename)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"Data saved to {filepath}")
        return filepath