import requests
import json
import os
import hmac
import hashlib
import time

# Binance API credentials
API_KEY = "HcCg0rZcc3trcutzN2L9WMluUgnEV0UXxol5NaHVoldLQu1HgDPG9EhWM4IOF4jr"
API_SECRET = "Hu0RTJd4Os7HtM8TDxlWyYlFsVQ0YdPtqOfyzuP3kVrrWjV5zgdYFe7NkqNDbstx"

def fetch_binance_symbols(output_dir="binance_symbols"):
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Binance API endpoint for exchange info
    url = "https://api.binance.com/api/v3/exchangeInfo"
    
    # Headers with API key
    headers = {
        'X-MBX-APIKEY': API_KEY
    }
    
    try:
        # Make the API request with headers
        response = requests.get(url, headers=headers)
        
        # Check if request was successful
        if response.status_code != 200:
            raise Exception(f"API call failed with status code {response.status_code}")
        
        # Parse the response
        data = response.json()
        
        # Save all symbols to a JSON file
        output_file = os.path.join(output_dir, 'binance_symbols.json')
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
            
        print(f"Successfully saved {len(data['symbols'])} symbols to {output_file}")
        
        # Print some basic information
        print("\nSample of available trading pairs:")
        for symbol in data['symbols'][:10]:  # Show first 10 symbols
            print(f"- {symbol['symbol']} ({symbol['status']})")
            
        return data
        
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

if __name__ == '__main__':
    try:
        print("Fetching Binance trading pairs...")
        symbols_data = fetch_binance_symbols()
        
        if symbols_data:
            print(f"\nTotal number of trading pairs: {len(symbols_data['symbols'])}")
            
    except Exception as e:
        print(f"An error occurred: {e}") 